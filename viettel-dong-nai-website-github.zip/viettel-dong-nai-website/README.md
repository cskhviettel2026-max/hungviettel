# Website Viettel Đồng Nai — Lê Ngọc Hùng

Mã nguồn trang hiện tại: https://viettel-dong-nai-hung-giai-phap-so.lemonyboot3.chatgpt.site

## Nội dung thư mục
- `index.html`: giao diện website, CSS và JavaScript.
- `assets/`: ảnh cá nhân, ảnh minh họa 5 sản phẩm và font Viettel trong `assets/fonts/`.
- `apps-script/`: mã Google Apps Script, giao diện dùng trên Google và hướng dẫn cài đặt.
- `.nojekyll`: cho phép phục vụ các tệp tĩnh trên GitHub Pages.

## Đưa lên GitHub
1. Giải nén ZIP.
2. Tạo repository trên GitHub.
3. Chọn **Add file → Upload files** và tải toàn bộ nội dung bên trong thư mục này lên repository. Để `index.html` ngay tại thư mục gốc, cùng cấp với `assets/` và `README.md`.
4. Chọn **Commit changes**.

Nếu dùng Git trên máy tính, mở terminal trong thư mục đã giải nén:

```sh
git init
git add .
git commit -m "Add Viettel Dong Nai website"
git branch -M main
git remote add origin https://github.com/TEN_TAI_KHOAN/TEN_REPOSITORY.git
git push -u origin main
```

Thay `TEN_TAI_KHOAN` và `TEN_REPOSITORY` bằng thông tin của anh.

## Chạy giao diện trên GitHub Pages
Trong repository, vào **Settings → Pages**, chọn **Deploy from a branch**, nhánh `main`, thư mục `/ (root)`, rồi lưu. Trang tĩnh không cần cài thư viện hoặc chạy build.

## Form đăng ký, Google Sheets và email
GitHub Pages chỉ chạy HTML/CSS/JavaScript; không chạy `Code.gs`. Mã Apps Script nằm trong `apps-script/`, có hướng dẫn ở `apps-script/HUONG_DAN.md`.

Sau khi triển khai Apps Script thành Web App, mở `index.html`, tìm `CONFIG.appsScriptUrl` và điền URL `/exec` của Web App. Khi khách gửi form trên trang tĩnh, trang cung cấp link sang trang đăng ký chính thức trên Apps Script. Việc lưu Google Sheets, gửi email và nhắc Zoom thực hiện trên bản Apps Script sau khi cấu hình và cấp quyền.

Bản chưa cấu hình không lưu đăng ký và không báo gửi email thành công. Link nhóm Tammi, lịch Zoom và thông tin Google Sheet được cấu hình riêng ở Apps Script; không đưa mật khẩu hoặc khóa bí mật lên repository.

## Chỉnh sửa
- Nội dung, link chi tiết, màu sắc và bố cục: `index.html`.
- Nếu dùng cả bản Apps Script, cập nhật tương ứng trong `apps-script/Index.html`.
- Ảnh và font đã kèm đầy đủ; giữ cấu trúc đường dẫn tương đối.
- Mục BHXH hiện dẫn đến form tư vấn, do chưa có link chi tiết riêng.

Đây là bản xuất từ mã nguồn của trang Sites trong cuộc trò chuyện này. Không chứa lịch sử Git hoặc thông tin xác thực quản trị.
