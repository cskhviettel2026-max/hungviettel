/** Viettel Đồng Nai — cấu hình trong Script Properties, không đặt link nhóm ở HTML. */
const HEADERS = ['ID','Created','Name','Phone','Email','Company','Products','Consent','Active','Confirmation','EmailError'];
const PRODUCT_NAMES = ['Tendoo','Viettel-CA','vContract','S-invoice','vBHXH'];
function cfg_(){ const p=PropertiesService.getScriptProperties();return {sheet:p.getProperty('SPREADSHEET_ID'),group:p.getProperty('TAMMI_GROUP_URL')||'',sender:p.getProperty('SENDER_NAME')||'Lê Ngọc Hùng • Viettel Đồng Nai',reply:p.getProperty('REPLY_TO')||''}; }
function book_(){const c=cfg_();if(!c.sheet)throw Error('Chưa cấu hình SPREADSHEET_ID');return SpreadsheetApp.openById(c.sheet);}
function doGet(){return HtmlService.createHtmlOutputFromFile('Index').setTitle('Giải pháp số Viettel • Lê Ngọc Hùng').addMetaTag('viewport','width=device-width, initial-scale=1');}
function setup(){
 const b=book_();[['Registrations',HEADERS],['Sessions',['SessionID','Title','StartISO','ZoomURL','Enabled','Products']],['ReminderLog',['Key','SentAt','Email','SessionID']],['Errors',['At','Context','Error']]].forEach(([name,headers])=>{let s=b.getSheetByName(name)||b.insertSheet(name);if(!s.getLastRow()){s.appendRow(headers);s.setFrozenRows(1);s.getRange(1,1,1,headers.length).setFontWeight('bold').setBackground('#e6002b').setFontColor('white');}});
 ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='processQueue').forEach(t=>ScriptApp.deleteTrigger(t));
 ScriptApp.newTrigger('processQueue').timeBased().everyMinutes(1).create();
}
function clean_(s,n){return String(s||'').trim().slice(0,n);}
function cell_(s){return /^[=+@-]/.test(String(s))?"'"+s:s;}
function esc_(v){return String(v||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function https_(url){return /^https:\/\/[^\s<>"']+$/.test(url);}
function register(d){
 const lock=LockService.getScriptLock();if(!lock.tryLock(10000))return {ok:false,error:'Hệ thống đang bận. Vui lòng thử lại.'};
 try{
 if(!d||d.website||d.consent!==true)throw Error('Vui lòng xác nhận đồng ý nhận tư vấn.');
 const name=clean_(d.name,100),phone=clean_(d.phone,20),email=clean_(d.email,150).toLowerCase(),id=clean_(d.requestId,60);
 const products=Array.isArray(d.products)?[...new Set(d.products)].filter(p=>PRODUCT_NAMES.includes(p)):[];
 if(!name||!/^\+?[0-9 ()-]{9,20}$/.test(phone)||!/^\S+@\S+\.\S+$/.test(email)||!products.length||!/^[a-zA-Z0-9-]{20,60}$/.test(id))throw Error('Thông tin chưa hợp lệ. Vui lòng kiểm tra lại.');
 const s=book_().getSheetByName('Registrations');if(!s)throw Error('Cần chạy setup trước khi nhận đăng ký.');
 const rows=s.getDataRange().getValues();let index=rows.findIndex((r,i)=>i>0&&r[0]===id);
 if(index>=0)return {ok:true,id,emailSent:rows[index][9]==='SENT'};
 // Giới hạn gửi lại theo email trong một giờ, tránh tạo nhiều email khi tải lại trang.
 const prior=rows.find((r,i)=>i>0&&String(r[4]).toLowerCase()===email&&Date.now()-new Date(r[1]).getTime()<3600000&&String(r[6])===products.join(', '));
 if(prior)return {ok:true,id:prior[0],emailSent:prior[9]==='SENT'};
 s.appendRow([id,new Date(),cell_(name),cell_(phone),email,cell_(clean_(d.company,150)),products.join(', '),true,true,'PENDING','']);
 const row=s.getLastRow();let sent=false;
 try{sendConfirmation_(s.getRange(row,1,1,11).getValues()[0]);s.getRange(row,10,1,2).setValues([['SENT','']]);sent=true;}catch(e){s.getRange(row,11).setValue(clean_(e.message,400));}
 return {ok:true,id,emailSent:sent};
 }catch(e){return {ok:false,error:e.message};}finally{lock.releaseLock();}
}
function mail_(email,subject,title,body,button,url){
 if(MailApp.getRemainingDailyQuota()<1)throw Error('Đã hết hạn mức email trong ngày.');
 const c=cfg_();let cta=url&&https_(url)?`<p style="margin:28px 0"><a href="${esc_(url)}" style="background:#e6002b;color:white;padding:14px 24px;text-decoration:none;border-radius:6px">${esc_(button)}</a></p>`:'';
 const html=`<div style="background:#f6f4f3;padding:28px;font-family:Arial,sans-serif;color:#292a30"><div style="max-width:600px;margin:auto;background:white;border-radius:12px;overflow:hidden"><div style="background:#e6002b;color:white;padding:28px;font-size:25px;font-weight:bold">viettel <span style="font-size:13px">ĐỒNG NAI</span></div><div style="padding:30px;line-height:1.7"><h1 style="font-size:25px">${esc_(title)}</h1>${body}${cta}<hr style="border:0;border-top:1px solid #eee"><p><b>Lê Ngọc Hùng</b><br>Viettel Đồng Nai • 0985 535 633<br>Kết nối Tammi qua số điện thoại trên.</p><p style="font-size:12px;color:#777">Bạn nhận email vì đã đăng ký tư vấn. Để dừng nhận email, liên hệ 0985 535 633${c.reply?' hoặc trả lời email này':''}.</p></div></div></div>`;
 const opts={to:email,subject,name:c.sender,htmlBody:html,body:html.replace(/<[^>]*>/g,' ')+(url?'\n'+url:'')};if(c.reply)opts.replyTo=c.reply;MailApp.sendEmail(opts);
}
function sendConfirmation_(r){const c=cfg_();mail_(r[4],'Đã nhận đăng ký của bạn • Viettel Đồng Nai','Chào '+r[2]+', cảm ơn bạn đã kết nối!',`<p>Đăng ký <b>${esc_(r[0])}</b> đã được ghi nhận.</p><p><b>Giải pháp bạn quan tâm:</b><br>${esc_(r[6])}</p><p>Khám phá Tendoo quản lý bán hàng, chữ ký số, hợp đồng điện tử, hóa đơn điện tử và phần mềm kê khai BHXH cùng anh Hùng.</p><p>${c.group?'Bấm nút bên dưới để tham gia cộng đồng Tammi.':'Anh Hùng sẽ gửi lời mời nhóm Tammi sau. Bạn cũng có thể kết nối Tammi theo số 0985 535 633.'}</p><p>Khi có lịch Zoom phù hợp, bạn sẽ nhận email nhắc trước buổi học. Đăng ký này chưa xác nhận thanh toán.</p>`,'Vào nhóm Tammi',c.group);}
function processQueue(){
 const lock=LockService.getScriptLock();if(!lock.tryLock(1000))return;
 try{
 const b=book_(),s=b.getSheetByName('Registrations'),rows=s.getDataRange().getValues();let budget=40;
 for(let i=1;i<rows.length&&budget>0;i++){const r=rows[i];if(r[8]!==true||r[7]!==true||r[9]==='SENT')continue;try{sendConfirmation_(r);s.getRange(i+1,10,1,2).setValues([['SENT','']]);}catch(e){s.getRange(i+1,11).setValue(clean_(e.message,400));}budget--;}
 const sessions=b.getSheetByName('Sessions').getDataRange().getValues();const log=b.getSheetByName('ReminderLog');const sent=new Set(log.getDataRange().getValues().slice(1).map(r=>r[0]));const now=Date.now();
 for(let j=1;j<sessions.length&&budget>0;j++){
 const [sid,title,start,url,enabled,filter]=sessions[j];if(enabled!==true||!sid||!title||!https_(String(url)))continue;
 // Bắt buộc giờ ISO có múi giờ; so sánh epoch độc lập múi giờ dự án.
 if(typeof start!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(Z|[+-]\d{2}:\d{2})$/.test(start))continue;
 const time=Date.parse(start);if(!Number.isFinite(time)||now<time-30*60000||now>=time)continue;
 const allowed=String(filter||'').split(',').map(x=>x.trim()).filter(Boolean);
 for(let i=1;i<rows.length&&budget>0;i++){const r=rows[i];if(r[8]!==true||r[7]!==true)continue;if(allowed.length&&!String(r[6]).split(', ').some(p=>allowed.includes(p)))continue;
 const key=String(sid)+'|'+time+'|'+r[4];if(sent.has(key))continue;
 try{const local=Utilities.formatDate(new Date(time),'Asia/Ho_Chi_Minh','HH:mm dd/MM/yyyy');mail_(r[4],'Sắp bắt đầu: '+title,'Hẹn bạn tại buổi Zoom',`<p>Chào ${esc_(r[2])},</p><p>Buổi <b>${esc_(title)}</b> sẽ bắt đầu lúc <b>${local} (giờ Việt Nam)</b>.</p><p>Hãy chuẩn bị thiết bị và tham gia bằng nút bên dưới.</p>`,'Tham gia Zoom',String(url));log.appendRow([key,new Date(),r[4],sid]);sent.add(key);}catch(e){b.getSheetByName('Errors').appendRow([new Date(),'Reminder '+sid,clean_(e.message,400)]);}budget--;}
 }
 }finally{lock.releaseLock();}
}
