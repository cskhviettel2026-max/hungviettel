# Landing page Viettel Đồng Nai — Lê Ngọc Hùng

## Cài bản đầy đủ có Google Sheets và email
1. Tạo Google Sheet mới, chép ID giữa /d/ và /edit trong URL.
2. Chọn Tiện ích mở rộng → Apps Script. Dán Code.gs. Tạo HTML tên Index rồi dán Index.html. Ảnh cá nhân đã nhúng nguyên nội dung, không cần upload ảnh lên dịch vụ khác.
3. Trong Cài đặt dự án, bật hiển thị appsscript.json và thay bằng file kèm theo.
4. Trong Script Properties thêm SPREADSHEET_ID = ID Google Sheet; TAMMI_GROUP_URL = link nhóm Tammi chính xác; SENDER_NAME = Lê Ngọc Hùng • Viettel Đồng Nai; REPLY_TO = email của anh. Link nhóm chỉ nằm ở máy chủ và email, không đặt trong HTML. Nếu chưa có link nhóm, email sẽ hướng dẫn liên hệ anh Hùng.
5. Chạy setup một lần, cấp quyền Google. Chạy lại setup sẽ thay trigger của processQueue, không xóa dữ liệu.
6. Triển khai → Bản triển khai mới → Ứng dụng web. Thực thi với tư cách tài khoản của anh; quyền truy cập Người dùng bất kỳ (nếu tài khoản Google cho phép). Dùng URL /exec làm trang đăng ký chính thức. Sau mỗi chỉnh mã, cập nhật bản triển khai sang phiên bản mới.
7. Gửi thử bằng email của anh: kiểm tra một dòng Registrations, popup và email. Gửi lại cùng lượt không tạo dòng trùng. Không dùng triển khai /dev cho khách.

## Lịch Zoom
Sheet Sessions có các cột: SessionID | Title | StartISO | ZoomURL | Enabled | Products.
- SessionID duy nhất cho mỗi buổi, ví dụ BUOI01. Không dùng lại ID cũ cho buổi khác.
- Đặt cột StartISO thành Văn bản thuần túy. Nhập đúng dạng 2026-12-01T20:00:00+07:00 (chỉ là ví dụ, không phải lịch đã xác nhận).
- ZoomURL: link https Zoom thật. Enabled: checkbox TRUE để bật buổi học.
- Products: để trống để gửi tất cả; hoặc Tendoo, Viettel-CA, vContract, S-invoice, vBHXH, cách nhau dấu phẩy để lọc theo sản phẩm.
- Trigger chạy mỗi phút, gửi từ mốc trước 30 phút đến trước giờ bắt đầu; không gửi khi buổi đã bắt đầu. Lịch Google không đảm bảo đúng từng giây. Người đăng ký trong khoảng này sẽ nhận nhắc ở lượt chạy tiếp theo.
- ReminderLog lưu mỗi email / buổi / giờ bắt đầu để chống gửi trùng. Thay giờ bắt đầu làm phát sinh lịch nhắc mới. Đặt Active FALSE trong Registrations để dừng email cho khách; Consent phải TRUE.
- Gmail / Apps Script có hạn mức gửi tùy tài khoản. Xem EmailError và Errors nếu gửi lỗi; đăng ký đã lưu vẫn được giữ. processQueue thử gửi lại email xác nhận ở lần chạy tiếp. Nếu hệ thống dừng lâu đến sau giờ bắt đầu sẽ bỏ nhắc của buổi đó.
- Khóa Script ngăn hai lượt chạy đồng thời. Có cửa sổ lỗi hiếm giữa gửi email và ghi trạng thái; Google MailApp không cung cấp khóa idempotency nên không bảo đảm gửi đúng một lần tuyệt đối.

## Bản Sites và bản Apps Script
Bản Sites là trang giới thiệu riêng tư cho chủ sở hữu. Bản Apps Script /exec chạy toàn bộ form thật, không cần xử lý CORS hay dùng fetch no-cors. Trong dist/index.html có CONFIG.appsScriptUrl: sau khi triển khai Google, điền URL /exec để khách từ bản Sites mở trang đăng ký chính thức. Không đưa thông tin cá nhân vào URL. Bản chưa cấu hình sẽ nói rõ chưa gửi dữ liệu, không hiển thị đăng ký thành công giả.

## Ảnh, video và thanh toán
Ảnh cá nhân đúng ảnh đã cung cấp, giữ trọn ảnh và chữ. Năm khối sản phẩm là minh họa chuyển động bằng CSS; không giả là ảnh chụp phần mềm. Trong CONFIG.videos thêm URL https của video thật theo khóa sản phẩm để hiện nút Xem video. Chưa có tệp/link video thực nên không có video thực trong bản giao.
Chưa nhận ảnh QR, tên người nhận, số tiền, lịch Zoom và link nhóm. Bản hiện tại nhận tư vấn, không thu tiền. Không tự tạo QR hoặc thông tin ngân hàng. Khi có QR, phải giữ đúng ảnh và thông tin đã xác nhận; ảnh giao dịch không tự xác nhận thanh toán.

## Kiểm tra trước khi dùng rộng rãi
Thử trên điện thoại và máy tính; thiếu trường; không chọn sản phẩm; một đăng ký thật bằng email của anh; gửi lại; email lỗi; một buổi Zoom thử cách hiện tại 31 phút. Xác nhận giờ Việt Nam, link nhóm, link Zoom. Giữ Google Sheet ở chế độ riêng tư. Link web app công khai có thể bị lạm dụng; mã có honeypot và chặn email trùng cùng lựa chọn trong một giờ, nhưng chưa tích hợp CAPTCHA. Xem hạn mức và giám sát lượng đăng ký; thêm chống spam phía máy chủ nếu triển khai chiến dịch lớn.

## Nguồn kỹ thuật
- https://developers.google.com/apps-script/guides/html/communication
- https://developers.google.com/apps-script/guides/triggers/installable
- https://developers.google.com/apps-script/guides/services/quotas

Các mô tả trên trang ở mức tổng quan; không công bố giá, cam kết pháp lý, ưu đãi hay số liệu chưa được cung cấp.

## Font nhận diện cập nhật
Dùng FS Magistral cho tiêu đề và FS PF Beau Sans Pro cho nội dung từ bộ font anh cung cấp. Bản web dùng WOFF2; Index.html nhúng font để triển khai Apps Script không cần hosting font riêng. Email giữ font hệ thống dự phòng vì nhiều ứng dụng email không hỗ trợ web font. Chữ trong ảnh gốc được giữ nguyên.
